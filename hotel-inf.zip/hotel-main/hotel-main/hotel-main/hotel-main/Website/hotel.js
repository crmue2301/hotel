// function Hotel(name, location) {
//     this.name = name;
//     this.location = location;
//     this.rooms = [];
//     this.reservations = [];
//     this.checkedInGuests = [];
// }

// // Define a Room object
// function Room(number, category, capacity) {
//     this.number = number;
//     this.category = category;
//     this.capacity = capacity;
//     this.isOccupied = false;
// }

// // Define a Reservation object
// function Reservation(guestName, checkInDate, checkOutDate, room) {
//     this.guestName = guestName;
//     this.checkInDate = new Date(checkInDate);
//     this.checkOutDate = new Date(checkOutDate);
//     this.room = room;
// }

// // Define a Guest object
// function Guest(name, room, checkInDate) {
//     this.name = name;
//     this.room = room;
//     this.checkInDate = new Date(checkInDate);
// }
